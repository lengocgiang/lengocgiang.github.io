---
layout: page
title: About me
permalink: /about/
banner_image: sample-banner-image-2.jpg
banner_image_alt: About me
---

Hi, I am Tom Warlker. I am a professional UI/UX designrer and web developer. I love being minimal and creative.

I prefer to serve with Php and Ruby based stacks and also love to work 
on [Jekyll][jekyll] and [Processwire CMS/CMF][pw].

### Contact me

Say `Hello` at [webcreatelk@gmail.com]({{ site.email }}) or find
me on

---

{% include social.html %}

[pw]: http://processwire.com
[jekyll]: http://jekyllrb.com
